function redirectToPage() {
    var genre = document.getElementById("books").value;
    
    
    if (genre === "fiction") {
        window.location.href = "fiction.html"; 
    } else if (genre === "epic") {
        window.location.href = "epic.html"; 
    } else if (genre === "mystery") {
        window.location.href = "mystery.html"; 
    } else if (genre === "fantasy") {
        window.location.href = "fantasy.html";
    } else if (genre === "biography") {
        window.location.href = "biography.html"; 
    } else if (genre === "science-fiction") {
        window.location.href = "science-fiction.html"; 
    }
    function addToCart(book) {
        localStorage.setItem('selectedBook', book);
        window.location.href = 'addcart.html';
    }
   
}