
<script>
// JavaScript for form validation
document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault(); // Prevent form from submitting

    // Get the input values
    const email = document.getElementById('email').value;
    const username = document.getElementById('username').value;

    // Validate email format
    const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

    if (!email.match(emailPattern)) {
        alert("Please enter a valid email address.");
        return; // Stop if email is invalid
    }

    // Validate username (simple check, at least 3 characters)
    if (username.length < 3) {
        alert("Username must be at least 3 characters long.");
        return; // Stop if username is invalid
    }

    // If everything is valid, proceed
    alert("Login successful!");

    // You can now submit the form or handle the login process
});
</script>